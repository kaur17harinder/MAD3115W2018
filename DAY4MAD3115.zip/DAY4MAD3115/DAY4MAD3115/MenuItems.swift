//
//  MenuItems.swift
//  DAY4MAD3115
//
//  Created by MacStudent on 2018-02-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class MenuItems {
    let names: [String] = ["Pizza" , "BBQ CHICKEN" , "Pasta" , "sausage PiZZA" , "MEAT" , "CORN FLAKES" , "CHOCOLATES" , "MUSHROOMS"]
    let prices: [Double] = [7.95 , 11.49 , 23.56 , 12.45 , 34.67 , 45.23 , 12.45 , 12.45]
    let specials:[Bool] = [false,true,true,false,true,false,true,true]
}
