//
//  webPageVC.swift
//  Day3_23Feb
//
//  Created by MacStudent on 2018-02-26.
//  Copyright © 2018 Kirandeep. All rights reserved.
//

import UIKit
import WebKit
//for creating webview using webkit view the minor change is to import a web kit library
class webPageVC: UIViewController {

    @IBOutlet weak var myWebView: WKWebView!
    //@IBOutlet weak var myWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        loadManualPage()
        //loadWebPage()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func loadWebPage(){
        let url = NSURL (string: "https:/www.google.com"); //casting
        let requestObj = NSURLRequest(url: url! as URL);   //requesting the url
        myWebView.load(requestObj as URLRequest);   //loading the request
        
    }
    func loadManualPage(){
        let localfilepath = Bundle.main.url(forResource: "muSub", withExtension: "html")
        let requestObj = NSURLRequest(url: localfilepath!);   //requesting the url
        myWebView.load(requestObj as URLRequest);   //loading the request
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
