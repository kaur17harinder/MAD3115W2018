//
//  RegisterVC.swift
//  LoginRegister
//
//  Created by Jigisha Patel on 2018-02-21.
//  Copyright © 2018 JK. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController, UIPickerViewDelegate , UIPickerViewDataSource {
    
   
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPostalCode: UITextField!
    @IBOutlet weak var txtDateOfBirth: UIDatePicker!
    @IBOutlet weak var txtCityPicker: UIPickerView!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtPhoneno: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    var cityList: [String] = ["ottawa" , "Toronto" , "windsor" , "Montreal" , "Quebec" , "Admenton" , "Jasper" , "Calgary" , "Vancouver" ]
    
    var selectedCityIndex : Int = 0
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = "Register"
        
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayValues))
        
        self.navigationItem.rightBarButtonItem = btnSubmit
    }

    @objc private func displayValues(){
        self.selectedCityIndex = self.txtCityPicker.selectedRow(inComponent: 0 )
        
        let allData : String = " \(self.txtName.text!) \n \(self.txtPhoneno.text!) \n \(self.txtDateOfBirth.date) \n \(self.cityList[selectedCityIndex]) \n \(self.txtPostalCode.text!) \n \(self.txtEmail.text!)"
        
        //let infoAlert = UIAlertController(title: "Verify", message: "Please verify your details", preferredStyle: .alert)
        let infoAlert = UIAlertController(title: "Verify", message: allData , preferredStyle: .alert)
        infoAlert.addAction(UIAlertAction(title: "confirm", style: .default, handler: {_ in self.displayWelcomeScreen()}))
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        
        self.present(infoAlert, animated: true)
    }
    
    func displayWelcomeScreen(){
        let welcomeSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let welcomeVC = welcomeSB.instantiateViewController(withIdentifier: "WelcomeScreen") as! WelcomeVC
        
        
        welcomeVC.welcomeTitle = txtName.text!
    navigationController?.pushViewController(welcomeVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //add data in picker
        self.txtCityPicker.delegate = self
        self.txtCityPicker.dataSource = self
    }

 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView:UIPickerView) -> Int{
        return 1
    }
    func pickerView(_ pickerView: UIPickerView ,numberOfRowsInComponent component: Int) -> Int {
        return self.cityList.count
    }
    func pickerView(_ pickerView: UIPickerView ,titleForRow row : Int , forComponent component : Int) -> String?{
        return self.cityList[row]
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
